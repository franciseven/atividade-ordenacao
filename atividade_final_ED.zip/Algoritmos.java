// Integrantes da dupla:
// Francisco Emmanuel Marcolino Lino Dos Santos - 20210026821
// Hiago Da Silva Galdino - 20210026868

/*******************************
OBS: Para que o código funcione corretamente, a pasta "atividade_final_ED" deve estar em alguma das pastas Home, por exemplo: Documentos, Downloads, Músicas, Vídeos. Isso porque senão o código não encontrará o arquivo e exibirá a mensagem "Ocorreu um erro ao ler o arquivo"
*******************************/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;

public class Algoritmos {
    public static void main(String[] args) {

        // Exemplo para testar os algoritmos
        double[] arrayExemplo = { 64, 25, 34, 12, 22, 11, 90 };
        
        System.out.println();
        System.out.println("Array exemplo: " + Arrays.toString(arrayExemplo));
        System.out.println();
        
        double[] selectionSortArr = selectionSort(arrayExemplo.clone());
        System.out.println("Selection Sort: " + Arrays.toString(selectionSortArr));
        
        double[] bubbleSortArr = bubbleSort(arrayExemplo.clone());
        System.out.println("Bubble Sort: " + Arrays.toString(bubbleSortArr));
        
        double[] insertionSortArr = insertionSort(arrayExemplo.clone());
        System.out.println("Insertion Sort: " + Arrays.toString(insertionSortArr));
        
        double[] mergeSortArr = mergeSort(arrayExemplo.clone());
        System.out.println("Merge Sort: " + Arrays.toString(mergeSortArr));
        
        double[] quickSortArr = quickSort(arrayExemplo.clone());
        System.out.println("Quick Sort: " + Arrays.toString(quickSortArr));


        // Caminho do arquivo a ser lido

        String arquivo1 = "couting.txt";
        String pastaInterna = "instancias-numericas";
        String pastaInterna2 = "instancias-num";
        String arquivo2 = "num.1000.1.in";
        String arquivo3 = "num.1000.2.in";
        String arquivo4 = "num.1000.3.in";
        String arquivo5 = "num.1000.4.in";
        String arquivo6 = "num.10000.1.in";
        String arquivo7 = "num.10000.2.in";
        String arquivo8 = "num.10000.3.in";
        String arquivo9 = "num.10000.4.in";
        String arquivo10 = "num.100000.1.in";
        String arquivo11 = "num.100000.2.in";
        String arquivo12 = "num.100000.3.in";
        String arquivo13 = "num.100000.4.in";
        String caminhoArquivo2 = Paths.get(pastaInterna, pastaInterna2, arquivo2).toString();
        String caminhoArquivo3 = Paths.get(pastaInterna, pastaInterna2, arquivo3).toString();
        String caminhoArquivo4 = Paths.get(pastaInterna, pastaInterna2, arquivo4).toString();
        String caminhoArquivo5 = Paths.get(pastaInterna, pastaInterna2, arquivo5).toString();
        String caminhoArquivo6 = Paths.get(pastaInterna, pastaInterna2, arquivo6).toString();
        String caminhoArquivo7 = Paths.get(pastaInterna, pastaInterna2, arquivo7).toString();
        String caminhoArquivo8 = Paths.get(pastaInterna, pastaInterna2, arquivo8).toString();
        String caminhoArquivo9 = Paths.get(pastaInterna, pastaInterna2, arquivo9).toString();
        String caminhoArquivo10 = Paths.get(pastaInterna, pastaInterna2, arquivo10).toString();
        String caminhoArquivo11 = Paths.get(pastaInterna, pastaInterna2, arquivo11).toString();
        String caminhoArquivo12 = Paths.get(pastaInterna, pastaInterna2, arquivo12).toString();
        String caminhoArquivo13 = Paths.get(pastaInterna, pastaInterna2, arquivo13).toString();

        try {
            String conteudo1 = lerArquivo(arquivo1);
            String conteudo2 = lerArquivo(caminhoArquivo2);
            String conteudo3 = lerArquivo(caminhoArquivo3);
            String conteudo4 = lerArquivo(caminhoArquivo4);
            String conteudo5 = lerArquivo(caminhoArquivo5);
            String conteudo6 = lerArquivo(caminhoArquivo6);
            String conteudo7 = lerArquivo(caminhoArquivo7);
            String conteudo8 = lerArquivo(caminhoArquivo8);
            String conteudo9 = lerArquivo(caminhoArquivo9);
            String conteudo10 = lerArquivo(caminhoArquivo10);
            String conteudo11 = lerArquivo(caminhoArquivo11);
            String conteudo12 = lerArquivo(caminhoArquivo12);
            String conteudo13 = lerArquivo(caminhoArquivo13);

            // Converter o conteúdo do arquivo para um array de inteiros
            double[] fileArray1 = Arrays.stream(conteudo1.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();
            
            double[] fileArray2 = Arrays.stream(conteudo2.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray3 = Arrays.stream(conteudo3.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray4 = Arrays.stream(conteudo4.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray5 = Arrays.stream(conteudo5.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();
            
            double[] fileArray6 = Arrays.stream(conteudo6.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray7 = Arrays.stream(conteudo7.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray8 = Arrays.stream(conteudo8.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray9 = Arrays.stream(conteudo9.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray10 = Arrays.stream(conteudo10.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray11 = Arrays.stream(conteudo11.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray12 = Arrays.stream(conteudo12.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

            double[] fileArray13 = Arrays.stream(conteudo13.split("\n"))
                    .mapToDouble(Double::parseDouble)
                    .toArray();

                
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo couting.txt
            
            long tempoInicialSelection1 = System.nanoTime();
            double[] selectionSortFileArr1 = selectionSort(fileArray1.clone());
            long tempoFinalSelection1 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr1));
            double tempoExecucaoSelection1 = (tempoFinalSelection1 - tempoInicialSelection1) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (couting.txt): %.3f ms%n", tempoExecucaoSelection1);

            long tempoInicialBubble1 = System.nanoTime();
            double[] bubbleSortFileArr1 = bubbleSort(fileArray1.clone());
            long tempoFinalBubble1 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr1));
            double tempoExecucaoBubble1 = (tempoFinalBubble1 - tempoInicialBubble1) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (couting.txt): %.3f ms%n", tempoExecucaoBubble1);

            long tempoInicialInsertion1 = System.nanoTime();
            double[] insertionSortFileArr1 = insertionSort(fileArray1.clone());
            long tempoFinalInsertion1 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr1));
            double tempoExecucaoInsertion1 = (tempoFinalInsertion1 - tempoInicialInsertion1) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (couting.txt): %.3f ms%n", tempoExecucaoInsertion1);

            long tempoInicialMerge1 = System.nanoTime();
            double[] mergeSortFileArr1 = mergeSort(fileArray1.clone());
            long tempoFinalMerge1 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr1));
            double tempoExecucaoMerge1 = (tempoFinalMerge1 - tempoInicialMerge1) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (couting.txt): %.3f ms%n", tempoExecucaoMerge1);

            long tempoInicialQuick1 = System.nanoTime();
            double[] quickSortFileArr1 = quickSort(fileArray1.clone());
            long tempoFinalQuick1 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr1));
            double tempoExecucaoQuick1 = (tempoFinalQuick1 - tempoInicialQuick1) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (couting.txt): %.3f ms%n", tempoExecucaoQuick1);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.1000.1.in

            long tempoInicialSelection2 = System.nanoTime();
            double[] selectionSortFileArr2 = selectionSort(fileArray2.clone());
            long tempoFinalSelection2 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr2));
            double tempoExecucaoSelection2 = (tempoFinalSelection2 - tempoInicialSelection2) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoSelection2);

            long tempoInicialBubble2 = System.nanoTime();
            double[] bubbleSortFileArr2 = bubbleSort(fileArray2.clone());
            long tempoFinalBubble2 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr2));
            double tempoExecucaoBubble2 = (tempoFinalBubble2 - tempoInicialBubble2) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoBubble2);

            long tempoInicialInsertion2 = System.nanoTime();
            double[] insertionSortFileArr2 = insertionSort(fileArray2.clone());
            long tempoFinalInsertion2 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr2));
            double tempoExecucaoInsertion2 = (tempoFinalInsertion2 - tempoInicialInsertion2) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoInsertion2);

            long tempoInicialMerge2 = System.nanoTime();
            double[] mergeSortFileArr2 = mergeSort(fileArray2.clone());
            long tempoFinalMerge2 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr2));
            double tempoExecucaoMerge2 = (tempoFinalMerge2 - tempoInicialMerge2) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoMerge2);

            long tempoInicialQuick2 = System.nanoTime();
            double[] quickSortFileArr2 = quickSort(fileArray2.clone());
            long tempoFinalQuick2 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr2));
            double tempoExecucaoQuick2 = (tempoFinalQuick2 - tempoInicialQuick2) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoQuick2);

            
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.1000.2.in

            long tempoInicialSelection3 = System.nanoTime();
            double[] selectionSortFileArr3 = selectionSort(fileArray3.clone());
            long tempoFinalSelection3 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr3));
            double tempoExecucaoSelection3 = (tempoFinalSelection3 - tempoInicialSelection3) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoSelection3);

            long tempoInicialBubble3 = System.nanoTime();
            double[] bubbleSortFileArr3 = bubbleSort(fileArray3.clone());
            long tempoFinalBubble3 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr3));
            double tempoExecucaoBubble3 = (tempoFinalBubble3 - tempoInicialBubble3) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoBubble3);

            long tempoInicialInsertion3 = System.nanoTime();
            double[] insertionSortFileArr3 = insertionSort(fileArray3.clone());
            long tempoFinalInsertion3 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr3));
            double tempoExecucaoInsertion3 = (tempoFinalInsertion3 - tempoInicialInsertion3) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoInsertion3);

            long tempoInicialMerge3 = System.nanoTime();
            double[] mergeSortFileArr3 = mergeSort(fileArray3.clone());
            long tempoFinalMerge3 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr3));
            double tempoExecucaoMerge3 = (tempoFinalMerge3 - tempoInicialMerge3) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoMerge3);

            long tempoInicialQuick3 = System.nanoTime();
            double[] quickSortFileArr3 = quickSort(fileArray3.clone());
            long tempoFinalQuick3 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr3));
            double tempoExecucaoQuick3 = (tempoFinalQuick3 - tempoInicialQuick3) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoQuick3);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.1000.3.in

            long tempoInicialSelection4 = System.nanoTime();
            double[] selectionSortFileArr4 = selectionSort(fileArray4.clone());
            long tempoFinalSelection4 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr4));
            double tempoExecucaoSelection4 = (tempoFinalSelection4 - tempoInicialSelection4) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoSelection4);

            long tempoInicialBubble4 = System.nanoTime();
            double[] bubbleSortFileArr4 = bubbleSort(fileArray4.clone());
            long tempoFinalBubble4 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr4));
            double tempoExecucaoBubble4 = (tempoFinalBubble4 - tempoInicialBubble4) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoBubble4);

            long tempoInicialInsertion4 = System.nanoTime();
            double[] insertionSortFileArr4 = insertionSort(fileArray4.clone());
            long tempoFinalInsertion4 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr4));
            double tempoExecucaoInsertion4 = (tempoFinalInsertion4 - tempoInicialInsertion4) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoInsertion4);

            long tempoInicialMerge4 = System.nanoTime();
            double[] mergeSortFileArr4 = mergeSort(fileArray4.clone());
            long tempoFinalMerge4 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr4));
            double tempoExecucaoMerge4 = (tempoFinalMerge4 - tempoInicialMerge4) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoMerge4);

            long tempoInicialQuick4 = System.nanoTime();
            double[] quickSortFileArr4 = quickSort(fileArray4.clone());
            long tempoFinalQuick4 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr4));
            double tempoExecucaoQuick4 = (tempoFinalQuick4 - tempoInicialQuick4) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoQuick4);

            
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.1000.4.in

            long tempoInicialSelection5 = System.nanoTime();
            double[] selectionSortFileArr5 = selectionSort(fileArray5.clone());
            long tempoFinalSelection5 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr5));
            double tempoExecucaoSelection5 = (tempoFinalSelection5 - tempoInicialSelection5) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoSelection5);

            long tempoInicialBubble5 = System.nanoTime();
            double[] bubbleSortFileArr5 = bubbleSort(fileArray5.clone());
            long tempoFinalBubble5 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr5));
            double tempoExecucaoBubble5 = (tempoFinalBubble5 - tempoInicialBubble5) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoBubble5);

            long tempoInicialInsertion5 = System.nanoTime();
            double[] insertionSortFileArr5 = insertionSort(fileArray5.clone());
            long tempoFinalInsertion5 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr5));
            double tempoExecucaoInsertion5 = (tempoFinalInsertion5 - tempoInicialInsertion5) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoInsertion5);

            long tempoInicialMerge5 = System.nanoTime();
            double[] mergeSortFileArr5 = mergeSort(fileArray5.clone());
            long tempoFinalMerge5 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr5));
            double tempoExecucaoMerge5 = (tempoFinalMerge5 - tempoInicialMerge5) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoMerge5);

            long tempoInicialQuick5 = System.nanoTime();
            double[] quickSortFileArr5 = quickSort(fileArray5.clone());
            long tempoFinalQuick5 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr5));
            double tempoExecucaoQuick5 = (tempoFinalQuick5 - tempoInicialQuick5) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoQuick5);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.10000.1.in

            long tempoInicialSelection6 = System.nanoTime();
            double[] selectionSortFileArr6 = selectionSort(fileArray6.clone());
            long tempoFinalSelection6 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr6));
            double tempoExecucaoSelection6 = (tempoFinalSelection6 - tempoInicialSelection6) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoSelection6);

            long tempoInicialBubble6 = System.nanoTime();
            double[] bubbleSortFileArr6 = bubbleSort(fileArray6.clone());
            long tempoFinalBubble6 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr6));
            double tempoExecucaoBubble6 = (tempoFinalBubble6 - tempoInicialBubble6) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoBubble6);

            long tempoInicialInsertion6 = System.nanoTime();
            double[] insertionSortFileArr6 = insertionSort(fileArray6.clone());
            long tempoFinalInsertion6 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr6));
            double tempoExecucaoInsertion6 = (tempoFinalInsertion6 - tempoInicialInsertion6) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoInsertion6);

            long tempoInicialMerge6 = System.nanoTime();
            double[] mergeSortFileArr6 = mergeSort(fileArray6.clone());
            long tempoFinalMerge6 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr6));
            double tempoExecucaoMerge6 = (tempoFinalMerge6 - tempoInicialMerge6) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoMerge6);

            long tempoInicialQuick6 = System.nanoTime();
            double[] quickSortFileArr6 = quickSort(fileArray6.clone());
            long tempoFinalQuick6 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr6));
            double tempoExecucaoQuick6 = (tempoFinalQuick6 - tempoInicialQuick6) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoQuick6);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.10000.2.in

            long tempoInicialSelection7 = System.nanoTime();
            double[] selectionSortFileArr7 = selectionSort(fileArray7.clone());
            long tempoFinalSelection7 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr7));
            double tempoExecucaoSelection7 = (tempoFinalSelection7 - tempoInicialSelection7) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoSelection7);

            long tempoInicialBubble7 = System.nanoTime();
            double[] bubbleSortFileArr7 = bubbleSort(fileArray7.clone());
            long tempoFinalBubble7 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr7));
            double tempoExecucaoBubble7 = (tempoFinalBubble7 - tempoInicialBubble7) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoBubble7);

            long tempoInicialInsertion7 = System.nanoTime();
            double[] insertionSortFileArr7 = insertionSort(fileArray7.clone());
            long tempoFinalInsertion7 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr7));
            double tempoExecucaoInsertion7 = (tempoFinalInsertion7 - tempoInicialInsertion7) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoInsertion7);

            long tempoInicialMerge7 = System.nanoTime();
            double[] mergeSortFileArr7 = mergeSort(fileArray7.clone());
            long tempoFinalMerge7 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr7));
            double tempoExecucaoMerge7 = (tempoFinalMerge7 - tempoInicialMerge7) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoMerge7);

            long tempoInicialQuick7 = System.nanoTime();
            double[] quickSortFileArr7 = quickSort(fileArray7.clone());
            long tempoFinalQuick7 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr7));
            double tempoExecucaoQuick7 = (tempoFinalQuick7 - tempoInicialQuick7) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoQuick7);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.10000.3.in

            long tempoInicialSelection8 = System.nanoTime();
            double[] selectionSortFileArr8 = selectionSort(fileArray8.clone());
            long tempoFinalSelection8 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr8));
            double tempoExecucaoSelection8 = (tempoFinalSelection8 - tempoInicialSelection8) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoSelection8);

            long tempoInicialBubble8 = System.nanoTime();
            double[] bubbleSortFileArr8 = bubbleSort(fileArray8.clone());
            long tempoFinalBubble8 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr8));
            double tempoExecucaoBubble8 = (tempoFinalBubble8 - tempoInicialBubble8) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoBubble8);

            long tempoInicialInsertion8 = System.nanoTime();
            double[] insertionSortFileArr8 = insertionSort(fileArray8.clone());
            long tempoFinalInsertion8 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr8));
            double tempoExecucaoInsertion8 = (tempoFinalInsertion8 - tempoInicialInsertion8) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoInsertion8);

            long tempoInicialMerge8 = System.nanoTime();
            double[] mergeSortFileArr8 = mergeSort(fileArray8.clone());
            long tempoFinalMerge8 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr8));
            double tempoExecucaoMerge8 = (tempoFinalMerge8 - tempoInicialMerge8) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoMerge8);

            long tempoInicialQuick8 = System.nanoTime();
            double[] quickSortFileArr8 = quickSort(fileArray8.clone());
            long tempoFinalQuick8 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr8));
            double tempoExecucaoQuick8 = (tempoFinalQuick8 - tempoInicialQuick8) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoQuick8);

            
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.10000.4.in

            long tempoInicialSelection9 = System.nanoTime();
            double[] selectionSortFileArr9 = selectionSort(fileArray9.clone());
            long tempoFinalSelection9 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr9));
            double tempoExecucaoSelection9 = (tempoFinalSelection9 - tempoInicialSelection9) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoSelection9);

            long tempoInicialBubble9 = System.nanoTime();
            double[] bubbleSortFileArr9 = bubbleSort(fileArray9.clone());
            long tempoFinalBubble9 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr9));
            double tempoExecucaoBubble9 = (tempoFinalBubble9 - tempoInicialBubble9) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoBubble9);

            long tempoInicialInsertion9 = System.nanoTime();
            double[] insertionSortFileArr9 = insertionSort(fileArray9.clone());
            long tempoFinalInsertion9 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr9));
            double tempoExecucaoInsertion9 = (tempoFinalInsertion9 - tempoInicialInsertion9) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoInsertion9);

            long tempoInicialMerge9 = System.nanoTime();
            double[] mergeSortFileArr9 = mergeSort(fileArray9.clone());
            long tempoFinalMerge9 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr9));
            double tempoExecucaoMerge9 = (tempoFinalMerge9 - tempoInicialMerge9) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoMerge9);

            long tempoInicialQuick9 = System.nanoTime();
            double[] quickSortFileArr9 = quickSort(fileArray9.clone());
            long tempoFinalQuick9 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr9));
            double tempoExecucaoQuick9 = (tempoFinalQuick9 - tempoInicialQuick9) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoQuick9);
            
            
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.100000.1.in

            long tempoInicialSelection10 = System.nanoTime();
            double[] selectionSortFileArr10 = selectionSort(fileArray10.clone());
            long tempoFinalSelection10 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr10));
            double tempoExecucaoSelection10 = (tempoFinalSelection10 - tempoInicialSelection10) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoSelection10);

            long tempoInicialBubble10 = System.nanoTime();
            double[] bubbleSortFileArr10 = bubbleSort(fileArray10.clone());
            long tempoFinalBubble10 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr10));
            double tempoExecucaoBubble10 = (tempoFinalBubble10 - tempoInicialBubble10) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoBubble10);

            long tempoInicialInsertion10 = System.nanoTime();
            double[] insertionSortFileArr10 = insertionSort(fileArray10.clone());
            long tempoFinalInsertion10 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr10));
            double tempoExecucaoInsertion10 = (tempoFinalInsertion10 - tempoInicialInsertion10) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoInsertion10);

            long tempoInicialMerge10 = System.nanoTime();
            double[] mergeSortFileArr10 = mergeSort(fileArray10.clone());
            long tempoFinalMerge10 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr10));
            double tempoExecucaoMerge10 = (tempoFinalMerge10 - tempoInicialMerge10) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoMerge10);

            long tempoInicialQuick10 = System.nanoTime();
            double[] quickSortFileArr10 = quickSort(fileArray10.clone());
            long tempoFinalQuick10 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr10));
            double tempoExecucaoQuick10 = (tempoFinalQuick10 - tempoInicialQuick10) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoQuick10);

            
            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.100000.2.in

            long tempoInicialSelection11 = System.nanoTime();
            double[] selectionSortFileArr11 = selectionSort(fileArray11.clone());
            long tempoFinalSelection11 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr11));
            double tempoExecucaoSelection11 = (tempoFinalSelection11 - tempoInicialSelection11) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoSelection11);

            long tempoInicialBubble11 = System.nanoTime();
            double[] bubbleSortFileArr11 = bubbleSort(fileArray11.clone());
            long tempoFinalBubble11 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr11));
            double tempoExecucaoBubble11 = (tempoFinalBubble11 - tempoInicialBubble11) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoBubble11);

            long tempoInicialInsertion11 = System.nanoTime();
            double[] insertionSortFileArr11 = insertionSort(fileArray11.clone());
            long tempoFinalInsertion11 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr11));
            double tempoExecucaoInsertion11 = (tempoFinalInsertion11 - tempoInicialInsertion11) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoInsertion11);

            long tempoInicialMerge11 = System.nanoTime();
            double[] mergeSortFileArr11 = mergeSort(fileArray11.clone());
            long tempoFinalMerge11 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr11));
            double tempoExecucaoMerge11 = (tempoFinalMerge11 - tempoInicialMerge11) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoMerge11);

            long tempoInicialQuick11 = System.nanoTime();
            double[] quickSortFileArr11 = quickSort(fileArray11.clone());
            long tempoFinalQuick11 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr11));
            double tempoExecucaoQuick11 = (tempoFinalQuick11 - tempoInicialQuick11) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoQuick11);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.100000.3.in

            long tempoInicialSelection12 = System.nanoTime();
            double[] selectionSortFileArr12 = selectionSort(fileArray12.clone());
            long tempoFinalSelection12 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr12));
            double tempoExecucaoSelection12 = (tempoFinalSelection12 - tempoInicialSelection12) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoSelection12);

            long tempoInicialBubble12 = System.nanoTime();
            double[] bubbleSortFileArr12 = bubbleSort(fileArray12.clone());
            long tempoFinalBubble12 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr12));
            double tempoExecucaoBubble12 = (tempoFinalBubble12 - tempoInicialBubble12) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoBubble12);

            long tempoInicialInsertion12 = System.nanoTime();
            double[] insertionSortFileArr12 = insertionSort(fileArray12.clone());
            long tempoFinalInsertion12 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr12));
            double tempoExecucaoInsertion12 = (tempoFinalInsertion12 - tempoInicialInsertion12) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoInsertion12);

            long tempoInicialMerge12 = System.nanoTime();
            double[] mergeSortFileArr12 = mergeSort(fileArray12.clone());
            long tempoFinalMerge12 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr12));
            double tempoExecucaoMerge12 = (tempoFinalMerge12 - tempoInicialMerge12) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoMerge12);

            long tempoInicialQuick12 = System.nanoTime();
            double[] quickSortFileArr12 = quickSort(fileArray12.clone());
            long tempoFinalQuick12 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr12));
            double tempoExecucaoQuick12 = (tempoFinalQuick12 - tempoInicialQuick12) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoQuick12);


            // Parte com marcação do tempo de processamento e exibição do resultado do processamento dos 5 algoritmos com o tempo marcado do arquivo num.100000.4.in

            long tempoInicialSelection13 = System.nanoTime();
            double[] selectionSortFileArr13 = selectionSort(fileArray13.clone());
            long tempoFinalSelection13 = System.nanoTime();
            System.out.println("Selection Sort (arquivo): " + Arrays.toString(selectionSortFileArr13));
            double tempoExecucaoSelection13 = (tempoFinalSelection13 - tempoInicialSelection13) / 1_000_000.0;
            System.out.printf("Tempo de processamento Selection Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoSelection13);

            long tempoInicialBubble13 = System.nanoTime();
            double[] bubbleSortFileArr13 = bubbleSort(fileArray13.clone());
            long tempoFinalBubble13 = System.nanoTime();
            System.out.println("\nBubble Sort (arquivo): " + Arrays.toString(bubbleSortFileArr13));
            double tempoExecucaoBubble13 = (tempoFinalBubble13 - tempoInicialBubble13) / 1000000.0;
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoBubble13);

            long tempoInicialInsertion13 = System.nanoTime();
            double[] insertionSortFileArr13 = insertionSort(fileArray13.clone());
            long tempoFinalInsertion13 = System.nanoTime();
            System.out.println("\nInsertion Sort (arquivo): " + Arrays.toString(insertionSortFileArr13));
            double tempoExecucaoInsertion13 = (tempoFinalInsertion13 - tempoInicialInsertion13) / 1_000_000.0;
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoInsertion13);

            long tempoInicialMerge13 = System.nanoTime();
            double[] mergeSortFileArr13 = mergeSort(fileArray13.clone());
            long tempoFinalMerge13 = System.nanoTime();
            System.out.println("\nMerge Sort (arquivo): " + Arrays.toString(mergeSortFileArr13));
            double tempoExecucaoMerge13 = (tempoFinalMerge13 - tempoInicialMerge13) / 1_000_000.0;
            System.out.printf("Tempo de processamento Merge Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoMerge13);

            long tempoInicialQuick13 = System.nanoTime();
            double[] quickSortFileArr13 = quickSort(fileArray13.clone());
            long tempoFinalQuick13 = System.nanoTime();
            System.out.println("\nQuick Sort (arquivo): " + Arrays.toString(quickSortFileArr13));
            double tempoExecucaoQuick13 = (tempoFinalQuick13 - tempoInicialQuick13) / 1_000_000.0;
            System.out.printf("Tempo de processamento Quick Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoQuick13);


            // Exposição simplificada de cada tempo de processamento
            System.out.printf("\nTempo de processamento Selection Sort (couting.txt): %.3f ms%n", tempoExecucaoSelection1);
            System.out.printf("Tempo de processamento Bubble Sort (couting.txt): %.3f ms%n", tempoExecucaoBubble1);
            System.out.printf("Tempo de processamento Insertion Sort (couting.txt): %.3f ms%n", tempoExecucaoInsertion1);
            System.out.printf("Tempo de processamento Merge Sort (couting.txt): %.3f ms%n", tempoExecucaoMerge1);
            System.out.printf("Tempo de processamento Quick Sort (couting.txt): %.3f ms%n", tempoExecucaoQuick1);

            System.out.printf("\nTempo de processamento Selection Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoSelection2);
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoBubble2);
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoInsertion2);
            System.out.printf("Tempo de processamento Merge Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoMerge2);
            System.out.printf("Tempo de processamento Quick Sort (num.1000.1.in): %.3f ms%n", tempoExecucaoQuick2);

            System.out.printf("\nTempo de processamento Selection Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoSelection3);
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoBubble3);
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoInsertion3);
            System.out.printf("Tempo de processamento Merge Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoMerge3);
            System.out.printf("Tempo de processamento Quick Sort (num.1000.2.in): %.3f ms%n", tempoExecucaoQuick3);

            System.out.printf("\nTempo de processamento Selection Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoSelection4);
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoBubble4);
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoInsertion4);
            System.out.printf("Tempo de processamento Merge Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoMerge4);
            System.out.printf("Tempo de processamento Quick Sort (num.1000.3.in): %.3f ms%n", tempoExecucaoQuick4);

            System.out.printf("\nTempo de processamento Selection Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoSelection5);
            System.out.printf("Tempo de processamento Bubble Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoBubble5);
            System.out.printf("Tempo de processamento Insertion Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoInsertion5);
            System.out.printf("Tempo de processamento Merge Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoMerge5);
            System.out.printf("Tempo de processamento Quick Sort (num.1000.4.in): %.3f ms%n", tempoExecucaoQuick5);

            System.out.printf("\nTempo de processamento Selection Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoSelection6);
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoBubble6);
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoInsertion6);
            System.out.printf("Tempo de processamento Merge Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoMerge6);
            System.out.printf("Tempo de processamento Quick Sort (num.10000.1.in): %.3f ms%n", tempoExecucaoQuick6);

            System.out.printf("\nTempo de processamento Selection Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoSelection7);
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoBubble7);
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoInsertion7);
            System.out.printf("Tempo de processamento Merge Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoMerge7);
            System.out.printf("Tempo de processamento Quick Sort (num.10000.2.in): %.3f ms%n", tempoExecucaoQuick7);

            System.out.printf("\nTempo de processamento Selection Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoSelection8);
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoBubble8);
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoInsertion8);
            System.out.printf("Tempo de processamento Merge Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoMerge8);
            System.out.printf("Tempo de processamento Quick Sort (num.10000.3.in): %.3f ms%n", tempoExecucaoQuick8);

            System.out.printf("\nTempo de processamento Selection Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoSelection9);
            System.out.printf("Tempo de processamento Bubble Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoBubble9);
            System.out.printf("Tempo de processamento Insertion Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoInsertion9);
            System.out.printf("Tempo de processamento Merge Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoMerge9);
            System.out.printf("Tempo de processamento Quick Sort (num.10000.4.in): %.3f ms%n", tempoExecucaoQuick9);

            System.out.printf("\nTempo de processamento Selection Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoSelection10);
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoBubble10);
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoInsertion10);
            System.out.printf("Tempo de processamento Merge Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoMerge10);
            System.out.printf("Tempo de processamento Quick Sort (num.100000.1.in): %.3f ms%n", tempoExecucaoQuick10);

            System.out.printf("\nTempo de processamento Selection Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoSelection11);
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoBubble11);
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoInsertion11);
            System.out.printf("Tempo de processamento Merge Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoMerge11);
            System.out.printf("Tempo de processamento Quick Sort (num.100000.2.in): %.3f ms%n", tempoExecucaoQuick11);

            System.out.printf("\nTempo de processamento Selection Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoSelection12);
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoBubble12);
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoInsertion12);
            System.out.printf("Tempo de processamento Merge Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoMerge12);
            System.out.printf("Tempo de processamento Quick Sort (num.100000.3.in): %.3f ms%n", tempoExecucaoQuick12);

            System.out.printf("\nTempo de processamento Selection Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoSelection13);
            System.out.printf("Tempo de processamento Bubble Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoBubble13);
            System.out.printf("Tempo de processamento Insertion Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoInsertion13);
            System.out.printf("Tempo de processamento Merge Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoMerge13);
            System.out.printf("Tempo de processamento Quick Sort (num.100000.4.in): %.3f ms%n", tempoExecucaoQuick13);

        } catch (IOException e) {
            System.out.println("Ocorreu um erro ao ler o arquivo: " + e.getMessage());
        }
    }

    // Função responsável pela leitura do arquivo
    public static String lerArquivo(String nomeArquivo) throws IOException {
        StringBuilder conteudo = new StringBuilder();
        try (BufferedReader leitor = new BufferedReader(new FileReader(nomeArquivo))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                conteudo.append(linha).append("\n");
            }
        }
        return conteudo.toString();
    }

    // Função responsável pela implementação do algoritmo Selection Sort
    public static double[] selectionSort(double[] arrayExemplo) {
        int n = arrayExemplo.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arrayExemplo[j] < arrayExemplo[minIndex]) {
                    minIndex = j;
                }
            }
            double temp = arrayExemplo[minIndex];
            arrayExemplo[minIndex] = arrayExemplo[i];
            arrayExemplo[i] = temp;
        }
        return arrayExemplo;
    }

    // Função responsável pela implementação do algoritmo Bubble Sort
    public static double[] bubbleSort(double[] arrayExemplo) {
        int n = arrayExemplo.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arrayExemplo[j] > arrayExemplo[j + 1]) {
                    double temp = arrayExemplo[j];
                    arrayExemplo[j] = arrayExemplo[j + 1];
                    arrayExemplo[j + 1] = temp;
                }
            }
        }
        return arrayExemplo;
    }

    // Função responsável pela implementação do algoritmo Insertion Sort
    public static double[] insertionSort(double[] arrayExemplo) {
        int n = arrayExemplo.length;
        for (int i = 1; i < n; i++) {
            double key = arrayExemplo[i];
            int j = i - 1;
            while (j >= 0 && arrayExemplo[j] > key) {
                arrayExemplo[j + 1] = arrayExemplo[j];
                j--;
            }
            arrayExemplo[j + 1] = key;
        }
        return arrayExemplo;
    }

    // Função responsável pela implementação do algoritmo Merge Sort
    public static double[] mergeSort(double[] arrayExemplo) {
        if (arrayExemplo.length <= 1) {
            return arrayExemplo;
        }
        int mid = arrayExemplo.length / 2;
        double[] left = mergeSort(Arrays.copyOfRange(arrayExemplo, 0, mid));
        double[] right = mergeSort(Arrays.copyOfRange(arrayExemplo, mid, arrayExemplo.length));
        return merge(left, right);
    }

    // Função privada que auxilia o Merge Sort
    private static double[] merge(double[] left, double[] right) {
        double[] merged = new double[left.length + right.length];
        int i = 0, j = 0, k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                merged[k++] = left[i++];
            } else {
                merged[k++] = right[j++];
            }
        }
        while (i < left.length) {
            merged[k++] = left[i++];
        }
        while (j < right.length) {
            merged[k++] = right[j++];
        }
        return merged;
    }

    // Função responsável pela implementação do algoritmo Quick Sort
    public static double[] quickSort(double[] arrayExemplo) {
        quickSortHelper(arrayExemplo, 0, arrayExemplo.length - 1);
        return arrayExemplo;
    }

    // Função privada que auxilia o Quick Sort
    private static void quickSortHelper(double[] arrayExemplo, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arrayExemplo, low, high);
            quickSortHelper(arrayExemplo, low, pivotIndex - 1);
            quickSortHelper(arrayExemplo, pivotIndex + 1, high);
        }
    }

    // Função privada que auxilia o Quick Sort
    private static int partition(double[] arrayExemplo, int low, int high) {
        double pivot = arrayExemplo[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arrayExemplo[j] < pivot) {
                i++;
                double temp = arrayExemplo[i];
                arrayExemplo[i] = arrayExemplo[j];
                arrayExemplo[j] = temp;
            }
        }
        double temp = arrayExemplo[i + 1];
        arrayExemplo[i + 1] = arrayExemplo[high];
        arrayExemplo[high] = temp;
        return i + 1;
    }
}